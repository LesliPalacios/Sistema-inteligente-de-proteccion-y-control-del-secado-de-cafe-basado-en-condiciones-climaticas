#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>
#include <SoftwareSerial.h>

LiquidCrystal_I2C lcd(0x27, 16, 2);
const int pinLluvia = 2;        
const int pinDHT = A0;          
#define DHTTYPE DHT11
DHT dht(pinDHT, DHTTYPE);       

const int pinIN1 = 3;           
const int pinIN2 = 4;           
const int pinENA = 5;           

SoftwareSerial miBluetooth(10, 11);

bool techoAbierto = false;      
bool esAutomatico = true;       
const int velocidadMotor = 255; 
const int tiempoGiro = 1000;    

void setup() {
  lcd.init(); lcd.backlight();
  dht.begin(); 
  miBluetooth.begin(9600);
  pinMode(pinLluvia, INPUT);
  pinMode(pinIN1, OUTPUT); pinMode(pinIN2, OUTPUT); pinMode(pinENA, OUTPUT);
  detenerTecho();
}

void loop() {
  bool hayLluvia = (digitalRead(pinLluvia) == LOW); 
  float temperatura = dht.readTemperature(); 
  float humedad = dht.readHumidity();
  
  String recomendacion = "Sistema estable";
  String diagnostico = "Normal";

  if (isnan(temperatura) || isnan(humedad)) return;

  // --- LÓGICA DE CONTROL Y LCD ---
  if (esAutomatico) {
    lcd.clear();
    if (hayLluvia) {
      cerrarTecho(); 
      lcd.setCursor(0, 0); lcd.print("LLUVIA DETECTADA");
      lcd.setCursor(0, 1); lcd.print("TECHO CERRADO");
      diagnostico = "Lluvia detectada";
      recomendacion = "Cubrir granos de cafe";
    } 
    else if (temperatura <= 27.0) {
      abrirTecho();
      lcd.setCursor(0, 0); lcd.print("TEMP: "); lcd.print(temperatura, 1); lcd.print(" C");
      lcd.setCursor(0, 1); lcd.print("TECHO ABIERTO");
      diagnostico = "Temp ideal";
      recomendacion = "Secando granos de cafe";
    } 
    else if (temperatura >= 29.0) {
      cerrarTecho();
      lcd.setCursor(0, 0); lcd.print("TEMP: "); lcd.print(temperatura, 1); lcd.print(" C");
      lcd.setCursor(0, 1); lcd.print("TECHO CERRADO");
      diagnostico = "Temp alta";
      recomendacion = "Protegiendo granos de cafe";
    }
    else {
      lcd.setCursor(0, 0); lcd.print("TEMP: "); lcd.print(temperatura, 1); lcd.print(" C");
      lcd.setCursor(0, 1); lcd.print(techoAbierto ? "TECHO ABIERTO" : "TECHO CERRADO");
      diagnostico = "Temp estable";
      recomendacion = "Monitoreando sistema";
    }
  }

  // --- ESCUCHA DE BOTONES ---
  if (miBluetooth.available() > 0) {
    char comando = miBluetooth.read();
    if (comando == 'A') { esAutomatico = false; abrirTecho(); }
    if (comando == 'C') { esAutomatico = false; cerrarTecho(); }
    if (comando == 'M') { esAutomatico = true; }
  }

  // --- ENVÍO A LA APP (Formato de 8 partes) ---
  miBluetooth.print("DATA,");
  miBluetooth.print(temperatura);
  miBluetooth.print(",");
  miBluetooth.print(humedad);
  miBluetooth.print(",");
  miBluetooth.print(hayLluvia ? 1 : 0);
  miBluetooth.print(",");
  miBluetooth.print(techoAbierto ? "ABIERTO" : "CERRADO");
  miBluetooth.print(",");
  miBluetooth.print(esAutomatico ? "AUTO" : "MANUAL");
  miBluetooth.print(",");
  miBluetooth.print(diagnostico); // Parte 6
  miBluetooth.print(",");
  miBluetooth.println(recomendacion); // Parte 7

  delay(2000); 
}

void abrirTecho() {
  if (!techoAbierto) {
    analogWrite(pinENA, velocidadMotor); 
    digitalWrite(pinIN1, HIGH); digitalWrite(pinIN2, LOW);
    delay(tiempoGiro); detenerTecho(); techoAbierto = true;
  }
}
void cerrarTecho() {
  if (techoAbierto) { 
    analogWrite(pinENA, velocidadMotor); 
    digitalWrite(pinIN1, LOW); digitalWrite(pinIN2, HIGH);
    delay(tiempoGiro); detenerTecho(); techoAbierto = false; 
  }
}
void detenerTecho() {
  analogWrite(pinENA, 0); digitalWrite(pinIN1, LOW); digitalWrite(pinIN2, LOW);
}